#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <platform.h>
#include <stdio.h>

#endif /* MAIN_H_INCLUDED */
