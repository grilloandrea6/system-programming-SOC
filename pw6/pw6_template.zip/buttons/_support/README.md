# _support

Board support package. Defines useful Hardware Abstraction Layers (HALs) to interface with the virtual prototype.
