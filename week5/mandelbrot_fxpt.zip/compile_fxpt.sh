#!/bin/bash
or1k-elf-gcc -Os -nostartfiles -o fractal_fxpt ../../support/crt0.S ../../support/exceptionHandlers.c ../../support/vgaPrint.c ../../support/uart.c ../../support/or32Print.c ../../support/caches.c ../../support/profiling.c ../fractal_fxpt.c ../main_fxpt.c
convert_or32 fractal_fxpt
