#ifndef TASK1_H_INCLUDED
#define TASK1_H_INCLUDED

void task1_main();

#endif /* TASK1_H_INCLUDED */
