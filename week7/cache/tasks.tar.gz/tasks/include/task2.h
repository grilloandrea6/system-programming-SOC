#ifndef TASK2_H_INCLUDED
#define TASK2_H_INCLUDED

void task2_main();

#endif /* TASK2_H_INCLUDED */
