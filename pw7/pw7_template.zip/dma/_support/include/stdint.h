#ifndef STDINT_H_INCLUDED
#define STDINT_H_INCLUDED

#include <stdint-gcc.h>

#endif /* STDINT_H_INCLUDED */
