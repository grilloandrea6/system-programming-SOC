#!/bin/bash
or1k-elf-gcc -Os -nostartfiles -o fractal_flpt ../../support/crt0.S ../../support/exceptionHandlers.c ../../support/vgaPrint.c ../../support/or32Print.c ../fractal_flpt.c ../main_flpt.c
convert_or32 fractal_flpt
