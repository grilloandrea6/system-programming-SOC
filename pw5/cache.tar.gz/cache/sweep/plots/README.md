# plots

Source code and data to generate the plots in the practical work.
