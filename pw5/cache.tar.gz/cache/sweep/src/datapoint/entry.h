#ifndef ENTRY_H_INCLUDED
#define ENTRY_H_INCLUDED

/**
 * @brief Entry for running all the data points.
 * 
 * Runs all the data points registered.
 * 
 */
void entry();

#endif /* ENTRY_H_INCLUDED */
