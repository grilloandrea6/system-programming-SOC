#ifndef ALL_ENTRIES
#define ALL_ENTRIES
#endif

void entry() {
    puts("");
    ALL_ENTRIES
}
