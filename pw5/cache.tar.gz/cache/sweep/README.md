# Cache Sweep

The project in this folder sweeps some compile-time parameters to analyze the interaction between the struct memory layout and caches.

You should explore the source code and play with the project; however, we do not expect you to modify anything.
