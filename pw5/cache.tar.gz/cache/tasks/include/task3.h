#ifndef TASK3_H_INCLUDED
#define TASK3_H_INCLUDED

void task3_main();

#endif /* TASK3_H_INCLUDED */
