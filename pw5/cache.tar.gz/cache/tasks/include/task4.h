#ifndef TASK4_H_INCLUDED
#define TASK4_H_INCLUDED

void task4_main();

#endif /* TASK4_H_INCLUDED */
